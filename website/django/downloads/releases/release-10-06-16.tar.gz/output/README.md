# Release README

### This directory contains source data, output data, and change data regarding the changes between this dataset and the previous dataset. The directories and files included are described below.

The `output` directory contains preprocessed source-specific data for each source used in the output data. For example, `ClinVarBrca.vcf` is a VCF file that contains all of the data gathered from ClinVar that is used on the BRCAExchange. Note that `1000G_brca.sorted.hg38.vcffor_pipeline` is a further processed version of `1000G_brca.sorted.hg38.vcf` with unused data removed to expediate the merge process when combining data from different sources.

The `release` directory contains all of the data produced by the merge process (`merged.tsv`, `annotated.tsv`, `aggregated.tsv`, `built.tsv`, and `built_with_change_types.tsv`) as well as `equivalent_variants.pkl`, which is a collection of variants that are found to be equivalent in the merge process.

The `wrong_genome_coors` directory contains files separated by source of all variants found to have incorrect genomic coordinates.
