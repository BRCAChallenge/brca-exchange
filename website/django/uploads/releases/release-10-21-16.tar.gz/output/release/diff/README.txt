This file contains basic information about the diff directory.


added.tsv: This file lists variants that are present in /Volumes/FLASH/UCSC/data/output/release/built.tsv and that are not present in /Volumes/FLASH/UCSC/data_beta/output/release/built_with_change_types.tsv as determined by their pyhgvs_Genomic_Coordinate_38 values.

removed.tsv: This file lists variants that are present in /Volumes/FLASH/UCSC/data_beta/output/release/built_with_change_types.tsv and that are not present in /Volumes/FLASH/UCSC/data/output/release/built.tsv as determined by their pyhgvs_Genomic_Coordinate_38 values.

v1_release_date: 10-7-2016

v1: /Volumes/FLASH/UCSC/data_beta/output/release/built_with_change_types.tsv

v2: /Volumes/FLASH/UCSC/data/output/release/built.tsv

diff.txt: This file lists variants and changes in /Volumes/FLASH/UCSC/data/output/release/built.tsv that were different for the same variant in /Volumes/FLASH/UCSC/data_beta/output/release/built_with_change_types.tsv . Variants are defined by their pyhgvs_Genomic_Coordinate_38 values.

added_data.tsv: This file lists variants and relevant additional data in /Volumes/FLASH/UCSC/data/output/release/built.tsv that was not present for the same variant in /Volumes/FLASH/UCSC/data_beta/output/release/built_with_change_types.tsv . Variants are defined by their pyhgvs_Genomic_Coordinate_38 values.

